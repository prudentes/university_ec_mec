# CHANGELOG

## 0.1.0 — 2026-10-01
- múltiplos projetos e propriedade;
- perfis master/editor/viewer;
- tema automático, claro e escuro;
- gerenciamento de zonas;
- mapa gerencial da edificação;
- planejamento de canteiro e áreas de vivência;
- recomendações automáticas e reativas;
- sincronização integral com a Entrega 1;
- matriz multicritério editável;
- exportação/importação JSON;
- trilha de auditoria;
- cenário inicial completo, sem pendências críticas.
