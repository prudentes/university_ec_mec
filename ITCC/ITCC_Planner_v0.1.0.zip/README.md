# ITCC Planner v0.1.0

Abra `index.html` diretamente no navegador.

Acesso inicial:
- usuário: ITCC
- senha: ITCC

O cenário da Igreja Santa Terezinha já vem preenchido com os mesmos números da Entrega 1:
- vão crítico 4,93 m;
- cerâmica R$ 202,39/m²;
- EPS R$ 206,29/m²;
- nervurada R$ 243,31/m²;
- maciça R$ 277,29/m²;
- seleção inicial EPS LT20;
- matriz: CER 83,6; EPS 84,6; NER 72,2; MAC 63,0.

Funcionalidades: múltiplos projetos, perfis, tema sistema/claro/escuro, zonas, mapa gerencial, canteiro, custos, cronograma, riscos, matriz, recomendações reativas, comentários, auditoria e JSON.

As recomendações são calculadas localmente por regras determinísticas; nenhuma IA ou conexão de rede é necessária.
